// @author: chen3861229
// @date: 2024-07-13

import config from "../constant.js";
import util from "../common/util.js";
import events from "../common/events.js";
import plex from "../plex.js";

async function example() {
  return "Hello Word!";
}

export default {
  example,
};