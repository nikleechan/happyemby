
// 选填项,用不到保持默认即可

// 转码配置,默认 false,将按之前逻辑强制直接播放
// plex 只能用自身服务转码,只有下面一个参数,多填写没用
const transcodeConfig = {
  enable: false, // 此为允许转码的总开关
};

export default {
  transcodeConfig,
}
